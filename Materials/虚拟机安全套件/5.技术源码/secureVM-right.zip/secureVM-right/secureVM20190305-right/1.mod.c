#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x1bd28fce, __VMLINUX_SYMBOL_STR(module_layout) },
	{ 0x9b388444, __VMLINUX_SYMBOL_STR(get_zeroed_page) },
	{ 0x7218edd9, __VMLINUX_SYMBOL_STR(vmcs_clear) },
	{ 0x7821deda, __VMLINUX_SYMBOL_STR(vmx_flush_tlb_modify) },
	{ 0x2ae81e89, __VMLINUX_SYMBOL_STR(testforshrinkpage_modify) },
	{ 0x27ba29c8, __VMLINUX_SYMBOL_STR(vmx_vcpu_run_sec) },
	{ 0x79aa04a2, __VMLINUX_SYMBOL_STR(get_random_bytes) },
	{ 0x7dec5b07, __VMLINUX_SYMBOL_STR(boot_cpu_data) },
	{ 0x485cd7f6, __VMLINUX_SYMBOL_STR(kvm_rebooting) },
	{ 0xc6861289, __VMLINUX_SYMBOL_STR(tdp_page_fault_modify) },
	{ 0x6a1973da, __VMLINUX_SYMBOL_STR(handle_pfn_modify) },
	{ 0xb4703335, __VMLINUX_SYMBOL_STR(handle_pfn_map) },
	{ 0x77e6bea9, __VMLINUX_SYMBOL_STR(vmwrite_error) },
	{ 0x27e1a049, __VMLINUX_SYMBOL_STR(printk) },
	{ 0x709cd8cb, __VMLINUX_SYMBOL_STR(kvm_spurious_fault) },
	{ 0x4c9d28b0, __VMLINUX_SYMBOL_STR(phys_base) },
	{ 0x67cbe5af, __VMLINUX_SYMBOL_STR(clean_page_modify) },
	{ 0x7ca84b7c, __VMLINUX_SYMBOL_STR(mmu_free_roots_modify) },
	{ 0x2b4dfb27, __VMLINUX_SYMBOL_STR(vmcs_writel) },
	{ 0x7f421f61, __VMLINUX_SYMBOL_STR(kvm_mmu_load_modify) },
	{ 0x97da0aa2, __VMLINUX_SYMBOL_STR(cpu_tlbstate) },
	{ 0xbdfb6dbb, __VMLINUX_SYMBOL_STR(__fentry__) },
	{ 0x8b9200fd, __VMLINUX_SYMBOL_STR(lookup_address) },
	{ 0x41d17a5e, __VMLINUX_SYMBOL_STR(ksm_page_modify) },
	{ 0xc06381d4, __VMLINUX_SYMBOL_STR(__do_page_fault) },
	{ 0x86df17ec, __VMLINUX_SYMBOL_STR(deflate_page_modify) },
	{ 0xebc94952, __VMLINUX_SYMBOL_STR(vmcs_readl) },
	{ 0x5cae9ef3, __VMLINUX_SYMBOL_STR(do_page_fault) },
	{ 0x5f01c652, __VMLINUX_SYMBOL_STR(inflate_page_modify) },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=kvm-intel,kvm";


MODULE_INFO(srcversion, "00EBEE79DAD8DC0F94C7E20");
