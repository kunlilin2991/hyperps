#include <linux/init.h>  
#include <linux/module.h>  
#include <linux/kernel.h> 
#include "hash.h"

static int __init my_init(void)  
{
/*
	HashNode * root;

	root = (HashNode *)malloc(sizeof(HashNode));
	HashNode1(root);

	InsertNode(root, 1, 8);
	InsertNode(root, 2, 0);
	InsertNode(root, 3, 4);
	InsertNode(root, 4, 7);
	InsertNode(root, 5, 4);
	InsertNode(root, 6, 3);
	InsertNode(root, 7, 8);

	int nvalue = 0;
	cout <<"The value of finding this node is : " << FindNode(root, 5, nvalue) << endl;
	cout <<"The value of finding this node is : " << FindNode(root, 9, nvalue) << endl;

	DeleteNode(root, 4);
	DeleteNode(root, 10);
*/
	cout <<"SecureVM.o is made ...... "<<endl; 
	return 0;	
}

static void __exit my_exit(void)  
{
	printk("Good bye!\n");
}
module_init(my_init);  
module_exit(my_exit);  
  
MODULE_LICENSE("GPL");
