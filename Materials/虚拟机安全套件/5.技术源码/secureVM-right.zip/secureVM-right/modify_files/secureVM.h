int clean_page_modify(struct page *page); //this function is used in /mm/vmscan.c shrink_page_list
int testforshrinkpage_modify(void);

void inflate_page_modify(struct page *page); //this function is used in /drivers/virtio/virtio_balloon.c
void deflate_page_modify(struct page *page); 
void ksm_page_modify(struct page *page,struct page *kpage);
